// src/Flashcard.jsx
function Flashcard({ card, isFlipped, onFlip }) {
const cardStyle = {
    width: '300px',
    height: '250px',
    perspective: '1000px',
    margin: '20px auto',
    cursor: 'pointer',
  };

  const innerStyle = {
    width: '100%',
    height: '100%',
    boxSizing: 'border-box',
    border: '2px solid #333',
    borderRadius: '15px',
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: isFlipped ? '#c7bef6' : '#ffffff',
    boxShadow: '0 4px 8px rgba(0,0,0,0.1)',
    transition: 'transform 0.6s',
    padding: '20px',
    textAlign: 'center'
  };

  return (
    <div style={cardStyle} onClick={onFlip}>
      <div style={innerStyle}>
        <small style={{ color: '#353232' }}>{card.partOfSpeech}</small>
        <h2 style={{ fontSize: '2.5rem', margin: '10px 0' }}>
          {isFlipped ? card.english : card.filipino}
        </h2>
        {isFlipped && (
          <p style={{ fontStyle: 'italic', fontSize: '0.9rem' }}>
            "{card.sentenceEng}"
          </p>
        )}
        {!isFlipped && (
          <p style={{ fontStyle: 'italic', fontSize: '0.9rem' }}>
            "{card.sentenceFil}"
          </p>
        )}
      </div>
    </div>
  );
}

export default Flashcard;