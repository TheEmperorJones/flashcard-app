export const initialDeck = [
    {
        id: 1,
        filipino: "salamat",
        english: "thank you",
        partOfSpeech: "interjection",
        sentenceFil: "Maraming salamat sa tulong mo.",
        sentenceEng: "Thank you very much for your help.",
        image: "https://placehold.co/200x200?text=Salamat"
    },
    {
        id: 2,
        filipino: "aso",
        english: "dog",
        partOfSpeech: "noun",
        sentenceFil: "Ang pangalan ng aso ay Fido.",
        sentenceEng: "The name of the dog is Fido.",
        image: "https://placehold.co/200x200?text=Aso"
    },
    {
        id: 3,
        filipino: "lola",
        english: "grandmother",
        partOfSpeech: "noun",
        sentenceFil: "Ang nanay ng nanay ko ay aking lola.",
        sentenceEng: "The mother of my mother is my grandmother.",
        image: "https://placehold.co/200x200?text=Lola"
    },
]