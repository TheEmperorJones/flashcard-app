import { useState } from 'react';
import './index.css';
import { initialDeck } from './deck';
import Flashcard from './Flashcard'; // 1. Import the new component

function App() {
  const [isFlipped, setIsFlipped] = useState(false);
  const [currentIndex, setCurrentIndex] = useState(0);

  const currentCard = initialDeck[currentIndex];

  if (!currentCard) return <h2>End of Deck! Refresh page to start over.</h2>;

  return (
    <div style={{ backgroundColor: 'darkBlue', textAlign: 'center', fontFamily: 'sans-serif' }}>
      <h1>My Tagalog Flashcards</h1>

      {/* 2. Use the component and pass the data down as "props" */}
      <Flashcard 
        card={currentCard} 
        isFlipped={isFlipped} 
        onFlip={() => setIsFlipped(!isFlipped)} 
      />

      <div style={{ marginTop: '45px' }}>
        <button onClick={() => {
          setCurrentIndex(currentIndex + 1);
          setIsFlipped(false);
        }}>
          Next Card
        </button>
      </div>
    </div>
  );
}

export default App;