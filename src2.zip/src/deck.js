export const initialDeck = [
    {
        id: 1,
        filipino: "salamat",
        english: "thank you",
        partOfSpeech: "interjection",
        sentenceFil: "Maraming salamat sa tulong mo.",
        sentenceEng: "Thank you very much for your help.",
        image: "https://images.unsplash.com/photo-1463736932348-4915535cf6f9?q=80&w=1332&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D"
    },
    {
        id: 2,
        filipino: "aso",
        english: "dog",
        partOfSpeech: "noun",
        sentenceFil: "Ang pangalan ng aso ay Fido.",
        sentenceEng: "The name of the dog is Fido.",
        image: "https://images.unsplash.com/photo-1568640347023-a616a30bc3bd?q=80&w=1173&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D"
    },
    {
        id: 3,
        filipino: "lola",
        english: "grandmother",
        partOfSpeech: "noun",
        sentenceFil: "Ang nanay ng nanay ko ay aking lola.",
        sentenceEng: "The mother of my mother is my grandmother.",
        image: "https://images.unsplash.com/photo-1581001510872-fefef7587e78?q=80&w=1291&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D"
    },
    {
        id: 4,
        filipino: "pera",
        english: "money",
        partOfSpeech: "noun",
        sentenceFil: "Mayroon ka bang sapat na pera?",
        sentenceEng: "Do you have enough money?",
        image: "https://images.unsplash.com/photo-1579621970795-87facc2f976d?q=80&w=1170&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D"
    },
    {
        id: 5,
        filipino: "tubig",
        english: "water",
        partOfSpeech: "noun",
        sentenceFil: "Ang babae uminom ng tubig",
        sentenceEng: "The woman drank water",
        image: "https://plus.unsplash.com/premium_photo-1674605363409-c40fc36aa304?q=80&w=1170&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D"
    },
    {   id: 6,
        filipino: "Dyego",
        english: "Diego",
        partOfSpeech: "noun",
        sentenceFil: "Dyego ay ang pinakagaling sa mundo.",
        sentenceEng: "Diego is the best in the world.",
        image: "https://media.istockphoto.com/id/539271283/photo/san-diego-interstate-8-sign.jpg?s=1024x1024&w=is&k=20&c=3JHFDA5cStlO7up9StVhVjQsnXzXMyNoEAAcu_aqvqs="
    },
    {
        id: 7,
        filipino: "matamis",
        english: "sweet",
        partOfSpeech: "adjective",
        sentenceFil: "Mga ubas ay matamis.",
        sentenceEng: "The grapes are sweet.",
        image: "https://media.istockphoto.com/id/2215312700/photo/brown-sugar-cubes-piled-in-a-wooden-bowl-on-a-dark-surface.jpg?s=1024x1024&w=is&k=20&c=ksMLQrlTAeOIt2fK20LLmJ8mW1NZ5pwnJHqYWhqhn0U="
    },
]