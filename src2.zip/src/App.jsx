import { useState } from 'react';
import './index.css';
import { initialDeck } from './deck';
import Flashcard from './Flashcard';

function App() {
  const [isFlipped, setIsFlipped] = useState(false);
  const [currentIndex, setCurrentIndex] = useState(0);

  const currentCard = initialDeck[currentIndex];

  if (!currentCard) return <h2 style={{ textAlign: 'center', marginTop: '100px'}}>End of Deck! <br></br> Refresh page to start over.</h2>;

  return (
    <div style={{ textAlign: 'center', fontFamily: 'sans-serif' }}>
      <h1>My Tagalog Flashcards</h1>

      <Flashcard 
        card={currentCard} 
        isFlipped={isFlipped} 
        onFlip={() => setIsFlipped(!isFlipped)} 
      />
      <p style={{ fontSize: 12 }}>click or tap to flip ↑</p>

      <div style={{ marginTop: '45px' }}>
        <button onClick={() => {
          setCurrentIndex(currentIndex + 1);
          setIsFlipped(false);
        }}>
          Next Card ➡️
        </button>
      </div>

      <div style={{ marginTop: '20px' }}>
        <button onClick={() => {
          setCurrentIndex(currentIndex - 1);
          setIsFlipped(false);
        }}>
          ⬅️ Prev Card
        </button>      
      </div>
    </div>
  );
}

export default App;